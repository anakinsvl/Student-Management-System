package com.example.studentmanagementsystem.features.taken_subject_crud;

public interface TakenSubjectCrudListener {
    void onTakenSubjectUpdated(boolean isUpdated);
}
