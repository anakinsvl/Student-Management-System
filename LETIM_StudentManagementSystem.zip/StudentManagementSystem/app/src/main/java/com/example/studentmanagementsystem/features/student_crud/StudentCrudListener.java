package com.example.studentmanagementsystem.features.student_crud;

public interface StudentCrudListener {
    void onStudentListUpdate(boolean isUpdated);
}
